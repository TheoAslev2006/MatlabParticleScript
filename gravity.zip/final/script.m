import Body2D.*;
clc; clear;





function bodyarray = genBodyArray(count ,massrange, universalStartVelocity, density)

    bodyarray = Body2D.empty(count, 0);
    for i = 1:count
        mass = massrange(1) + (massrange(2) - massrange(1)) * rand();
        density = density
        size = mass / density;
        pos = [randi([-10 10]) randi([-10 10])] .*size;
        bodyarray(i) = Body2D(pos, universalStartVelocity, [0 0], mass, size);
    end
    
end

G = 6.6743e-11;

A = 5e16^2 * pi

density = 2e45/A;

bodies = genBodyArray(10, [2e45 3e45], [0 0], density);

time = 0;
while(time <= 200 )
    time = time + 1
    for i = 1:numel(bodies) - 1
        m1 = bodies(i).mass;
        for j = i + 1 : numel(bodies)
           
            dPos = bodies(j).position - bodies(i).position;
            r = norm(dPos);
            if(r == 0)
                continue;
            end
            unitr = dPos / r;
        
            m2 = bodies(j).mass;
            F = G * (m2 * m1 / (r^2));
            
            a1 = F / m1 * unitr;
            a2 = -F / m2 * unitr;
        
            bodies(i).acceleration = bodies(i).acceleration + a1;
            bodies(j).acceleration = bodies(j).acceleration + a2;
        
         end
    end
    for p = 1:numel(bodies)
       
        bodies(p) = bodies(p).Update();
        
        [~,bodies, result] = bodies(p).checkCollition(bodies);
        if result
            break
        end
    end
    


    clf;
    hold on;
    for i = 1:numel(bodies)
        bodies(i).render();
    end
    
    axis equal;
    xlim([-150e11 150e11]);
    ylim([-150e11 150e11]);
    drawnow
end
