classdef Body2D

    properties
        position = [0 0];
        velocity = [0 0];
        acceleration = [0 0];
        mass = 1;
        radius = 1;
        circlearray = linspace(0, pi * 2, 15);
    end

    methods
        function obj = Body2D(position, velocity, acceleration,mass, radius)
            if nargin > 0
                obj.position = position;
                obj.velocity = velocity;
                obj.acceleration = acceleration;
                obj.mass = mass;
                obj.radius = radius;
            end
        end
        
        function obj = ApplyAcceleration(obj, acceleration)
            obj.acceleration = acceleration;
        end
        
        function obj = Update(obj)
            obj.velocity = obj.velocity + obj.acceleration;
            obj.position = obj.position + obj.velocity;
            obj.acceleration = [0 0];

        end
   
        function obj = render(obj)
            xA = obj.position(1) + (cos(obj.circlearray) .* obj.radius);
            yA = obj.position(2) + (sin(obj.circlearray) .* obj.radius);
            plot(xA, yA, "r-", LineWidth=5);
        end
        
        function [obj, bodies, result] = checkCollition(obj, bodies)
            result = false;
            for i = 1:numel(bodies)
                if isequal(bodies(i), obj)
                    continue
                end
                
                distance = norm(obj.position - bodies(i).position);
                if distance < (obj.radius + bodies(i).radius)
                    newBody = joinbody(obj, bodies(i));
                    idx1 = find(arrayfun(@(x) isequal(x, obj), bodies))
                    idx2 = find(arrayfun(@(x) isequal(x, bodies(i)), bodies))              
                    %idx1 = find(bodies = obj);
                    %idx2 = find(bodies == bodies(i));
                    bodies(idx1)=newBody;
                    bodies(idx2)=[];
                    result = true;
                    return;
                end
                
            end
            
        end    

        function newBody = joinbody(obj, body)
            
            if obj.mass >= body.mass 
                newposition = obj.position;  
            else
                newposition = body.position;
            end
            
            newmass = obj.mass + body.mass;
            newvelocity = (obj.velocity * obj.mass  + body.velocity * body.mass) ./ newmass .* 0.4;
            density = obj.mass / obj.radius;
            newradius  = newmass / density; 
            %A = pi*obj.radius^2 + pi* body.raius^2;
            %newradius =  sqrt(A/ pi);
            newacceleration = [0 0];
            newBody = Body2D(newposition, newvelocity, newacceleration, newmass, newradius);
        
        end
    end
end
